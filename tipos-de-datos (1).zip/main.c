/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define TAMANO 2



int main()
{
    
char c;
int x;
int arreglo [TAMANO];
double y;


printf("\n El tamaño en bytes de una variable char es: %d\n", sizeof(c));
printf(" El tamaño en bits es: %d\n",  sizeof(c)*8);
printf(" Y nibbles son: %d\n", sizeof(c)*2);


printf("\n El tamaño en bytes de una variable int es: %d\n", sizeof(x));
printf(" El tamaño en bits es: %d\n", sizeof(x)*8);
printf(" Y nibbles son: %d\n", sizeof(x)*2);

printf("\n El tamaño en bytes de una variable arreglo es: %d\n", sizeof(arreglo));
printf(" El tamaño en bits es: %d\n", sizeof(arreglo)*8);
printf(" Y nibbles son: %d\n", sizeof(arreglo)*2);


printf("\n El tamaño en bytes de una variable int es: %d\n", sizeof(y));
printf(" El tamaño en bits es: %d\n", sizeof(y)*8);
printf(" Y nibbles son: %d\n", sizeof(y)*2);


    return 0;
}
