/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUM_NEUMATICOS 4

void leerPresionNeumaticos(int * arregloPresiones){
    int i;
    srand (time(NULL));
    for (i=0; i<NUM_NEUMATICOS; i++)
    {
        arregloPresiones[i]=rand()%25+30;
    }
}


int main()
{
  int presionesNeumaticos[NUM_NEUMATICOS];
  int i; 
  leerPresionNeumaticos(presionesNeumaticos);
  
  printf("PRESIONES DE LOS NEUMATICOS");
  for(i=0; i<NUM_NEUMATICOS; i++)
  {
      printf("\nNeumatico %d: %d PSI",i+1,presionesNeumaticos[i]);
  }

    return 0;
}


