/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define nveces 4

void sensor(float *arregloPresiones);

void lectura();

int main ()
{
    float presiones[nveces];
    sensor(presiones);
    printf("NIVEL DE PRESION DE AUTO \n\n");
    for (int i = 0 ; i < nveces ; i++)
    {
        printf("%d La presion del carro es: %.1f PSI ", i+1, presiones[i]);
    
if (presiones[i] < 37.0)
        {
            printf("== El carro es chico\n");
        }
        else if (presiones[i] < 45.0)
        {
            printf("== El carro es mediano\n");
        }
            else
            {
                printf("== El carro es grande\n");
            }
    }
}

void sensor(float *arregloPresiones)
{
    srand(time(NULL));
    for (int i = 0 ; i < nveces ; i++)
    {
        arregloPresiones[i] = (float)rand()/RAND_MAX*(50-20)+20;
}
}
