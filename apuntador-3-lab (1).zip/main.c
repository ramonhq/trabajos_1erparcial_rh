/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUM_SENTEMPERATURA 12

void leerTemperatura(int * arreglotemperaturas){
    int i;
    srand (time(NULL));
    for (i=0; i<NUM_SENTEMPERATURA; i++)
    {
        arreglotemperaturas[i]=rand()%50+20;
    }
}


int main()
{
  int temp[NUM_SENTEMPERATURA];
  int i; 
  leerTemperatura(temp);
  
  printf("TEMPERATURA DE SENSOR BIOMEDICO");
  for(i=0; i<NUM_SENTEMPERATURA; i++)
  {
      printf("\nTEMPERATURA %d: %d °C",i+1,temp[i]);
  }

    return 0;
}

